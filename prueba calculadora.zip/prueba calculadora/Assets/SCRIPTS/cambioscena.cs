﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class cambioscena : MonoBehaviour
{

 public int numero;

    // Start is called before the first frame update
    public void CambioScena (int numero)
    {
        SceneManager.LoadScene(numero);
    }

}
