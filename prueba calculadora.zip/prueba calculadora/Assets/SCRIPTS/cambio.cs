﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cambio : MonoBehaviour
{
	public Text tex1;

	public void ponercero()
	{
		tex1.text = "0";
	}

	public void poneruno()
	{
		tex1.text = "1";
	}

	public void ponerdos()
	{
		tex1.text = "2";
	}

	public void ponertres()
	{
		tex1.text = "3";
	}

		public void ponercuatro()
	{
		tex1.text = "4";
	}

	public void ponercinco()
	{
		tex1.text = "5";
	}

		public void ponerseis()
	{
		tex1.text = "6";
	}

	public void ponersiete()
	{
		tex1.text = "7";
	}
}
